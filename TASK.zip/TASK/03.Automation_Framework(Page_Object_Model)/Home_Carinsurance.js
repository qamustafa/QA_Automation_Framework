describe ('Automated Regression Suite' ,function(){

	it('verify Username test 1' ,function(){
		
	/* If you want for non angular website please use foloowing */

		browser.waitForAngularEnabled(false);
	
		browser.get('https://covercheck.vwfsinsuranceportal.co.uk/');
	
		browser.manage().window().maximize();

	});
	
	
	

	var CarinsuranceDemos = require('./Carinsurance_Demo.js');
	

	
	it('should page object of Carinsurance_Demo',function(){
		
		CarinsuranceDemos.validregistration();
		CarinsuranceDemos.invalidregistration();
		CarinsuranceDemos.emptyregistration();
		
	});
	

});