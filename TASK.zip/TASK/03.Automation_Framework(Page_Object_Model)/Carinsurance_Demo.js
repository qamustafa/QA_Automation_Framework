var CarinsuranceDemo = function() {


 
 
  
     /*For validregistration Page*/
	 
   this.validregistration = function() {
		browser.get('https://covercheck.vwfsinsuranceportal.co.uk/');
		
		expect(browser.getTitle()).toEqual('Dealer Portal');
		
		expect($$('#dlg-dealersearch-title').isPresent('Drive Away Insurance')).toBeTruthy();
		expect($$('#dlg-dealersearch-subtitle').isPresent('Please enter the vehicle registration')).toBeTruthy();
	
		
		expect($$('input#vehicleReg').isPresent('ENTER REG')).toBeTruthy();
	
		element(by.id('vehicleReg')).sendKeys('OV12UYY');
		element(by.css('.track-search')).click();
	
		
		//verify text
	
		browser.sleep(5000);
		expect($$('input.in-tx-vehreg.ng-touched.ng-dirty.ng-valid').isPresent('OV12UYY')).toBeTruthy();
		browser.sleep(5000);
		expect($$('.result').isPresent('Result for : OV12UYY')).toBeTruthy();
		browser.sleep(5000);
		expect($('.resultDate').isPresent('09 FEB 2022 : 21 : 26')).toBeTruthy();
		browser.sleep(5000);
		expect($('.resultDate').isPresent('19 FEB 2022 : 04 : 59')).toBeTruthy();
  
   }
   
    /*For invalid registration Page*/
	
    this.invalidregistration = function() {

		browser.get('https://covercheck.vwfsinsuranceportal.co.uk/');
		
		element(by.id('vehicleReg')).sendKeys('OV12UY');
		element(by.css('.track-search')).click();
	
		
		//verify text
	
		browser.sleep(5000);
		expect($$('input.in-tx-vehreg.ng-touched.ng-dirty.ng-valid').isPresent('OV12UY')).toBeTruthy();
		browser.sleep(5000);
		expect($$('.result').isPresent('Sorry record not found')).toBeTruthy();
   }
   
    /*For Women Page*/
   
   this.emptyregistration = function() {
	   
		browser.get('https://covercheck.vwfsinsuranceportal.co.uk/');
		
		element(by.id('vehicleReg')).sendKeys('');
		element(by.css('.track-search')).click();
	
		
		//verify text
		browser.sleep(5000);
		expect($$('.error-required').isPresent('Please enter a valid car registration')).toBeTruthy();
		
		
  
   }
   

   

};
module.exports = new CarinsuranceDemo();