describe ('Direct Linegroup  Automated Regression Suite-----' ,function(){
	
	browser.waitForAngularEnabled(true);
	
	////////Test_Case1---------Positive////
	it('Test_Case1 With valid registration number-----Positive' ,function(){
		browser.get('https://covercheck.vwfsinsuranceportal.co.uk/');
		// Maximize Window //
		browser.manage().window().maximize();
		expect(browser.getTitle()).toEqual('Dealer Portal');
		browser.sleep(5000);
		expect($$('#dlg-dealersearch-title').isPresent('Drive Away Insurance')).toBeTruthy();
		expect($$('#dlg-dealersearch-subtitle').isPresent('Please enter the vehicle registration')).toBeTruthy();
		expect($$('input#vehicleReg').isPresent('ENTER REG')).toBeTruthy();
		element(by.id('vehicleReg')).sendKeys('OV12UYY');
		element(by.css('.track-search')).click();
		browser.sleep(5000);
		expect($$('input.in-tx-vehreg.ng-touched.ng-dirty.ng-valid').isPresent('OV12UYY')).toBeTruthy();
		expect($$('.result').isPresent('Result for : OV12UYY')).toBeTruthy();
		expect($('.resultDate').isPresent('09 FEB 2022 : 21 : 26')).toBeTruthy();
		expect($('.resultDate').isPresent('19 FEB 2022 : 04 : 59')).toBeTruthy();
		element(by.id('vehicleReg')).clear('');
		browser.refresh
	});
	
	////////Test_Case2-----Invalid Reg number ----Negative////
	it('Test Case2 Execution Without Reg number-------Negative' ,function(){
		
		browser.get('https://covercheck.vwfsinsuranceportal.co.uk/');
		//element(by.id('vehicleReg')).clear('');
		element(by.id('vehicleReg')).sendKeys('OV12UY');
		element(by.css('.track-search')).click();
		browser.sleep(5000);
		expect($$('input.in-tx-vehreg.ng-touched.ng-dirty.ng-valid').isPresent('OV12UY')).toBeTruthy();
		expect($$('.result').isPresent('Sorry record not found')).toBeTruthy();
	});
 
		////////Test_Case3-----Without Reg number ----Negative////
	it('Test Case3 Execution Without Reg number----Negative' ,function(){
		browser.get('https://covercheck.vwfsinsuranceportal.co.uk/');
		element(by.id('vehicleReg')).clear('');
		browser.sleep(5000);
		element(by.id('vehicleReg')).sendKeys('');
		element(by.css('.track-search')).click();
		browser.sleep(3000);
		expect($$('.error-required').isPresent('Please enter a valid car registration')).toBeTruthy();
		browser.close

	});

	
});